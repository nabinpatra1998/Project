from django.urls import path
from .views import (post_list, post_detail, post_create)

urlpatterns = [
    path('', post_list, name='post-list'),
    path('posts/<int:pk>/', post_detail, name='post-detail'),
    path('posts/new/', post_create, name='post-create'),
]