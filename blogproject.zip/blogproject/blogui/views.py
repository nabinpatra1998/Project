from django.shortcuts import render, redirect
import requests
from django.conf import settings
from django.contrib.auth.decorators import login_required
from .forms import PostForm, CommentForm
from rest_framework.authtoken.models import Token
from django.utils import timezone

API_BASE_URL = settings.API_BASE_URL

def post_list(request):
    response = requests.get(f'{API_BASE_URL}posts/')
    posts = response.json() if response.status_code == 200 else []
    return render(request, 'blogui/post_list.html', {'posts': posts})

def post_detail(request, pk):
    
    post_response = requests.get(f'{API_BASE_URL}posts/{pk}/')
    comments_response = requests.get(f'{API_BASE_URL}posts/{pk}/comments/')
    
    post = post_response.json() if post_response.status_code == 200 else None
    comments = comments_response.json() if comments_response.status_code == 200 else []
    
    if request.method == 'POST' and request.user.is_authenticated:
        form = CommentForm(request.POST)
        if form.is_valid():
            token, created = Token.objects.get_or_create(user=request.user)
            response = requests.post(
                f'{API_BASE_URL}posts/{pk}/comments/',
                data={'content': form.cleaned_data['content']},
                headers={'Authorization': f'Token {token.key}'}
            )
            if response.status_code == 201:
                return redirect('post-detail', pk=pk)
    else:
        form = CommentForm()
    
    return render(request, 'blogui/post_detail.html', {
        'post': post,
        'comments': comments,
        'form': form
    })

@login_required
def post_create(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            response = requests.post(
                f'{API_BASE_URL}posts/',
                data={
                    'title': form.cleaned_data['title'],
                    'content': form.cleaned_data['content']
                },
                headers={'Authorization': f'Token {request.user.auth_token.key}'}
            )
            if response.status_code == 201:
                return redirect('post-list')
    else:
        form = PostForm()
    return render(request, 'blogui/post_form.html', {'form': form})