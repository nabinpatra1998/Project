from django.urls import path
from .views import PostListCreate, PostRetrieveUpdateDestroy, CommentListCreate

urlpatterns = [
    path('posts/', PostListCreate.as_view(), name='post-list-create'),
    path('posts/<int:pk>/', PostRetrieveUpdateDestroy.as_view(), name='post-retrieve-update-destroy'),
    path('posts/<int:pk>/comments/', CommentListCreate.as_view(), name='comment-create'),
]
