from rest_framework import serializers
from .models import Post, Comment
from django.contrib.auth.models import User
from django.contrib.humanize.templatetags.humanize import naturaltime

class HumanDateTimeField(serializers.DateTimeField):
    def to_representation(self, value):
        return naturaltime(value)
    

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']

class CommentSerializer(serializers.ModelSerializer):
    author = UserSerializer(read_only=True)
    created_at = HumanDateTimeField(read_only=True)  
    class Meta:
        model = Comment
        fields = ['id', 'content', 'author', 'created_at']

class PostSerializer(serializers.ModelSerializer):
    author = UserSerializer(read_only=True)
    comments = CommentSerializer(many=True, read_only=True)
    created_at = HumanDateTimeField(read_only=True)
    updated_at = HumanDateTimeField(read_only=True)    
    class Meta:
        model = Post
        fields = ['id', 'title', 'content', 'author', 'created_at', 'updated_at', 'comments']