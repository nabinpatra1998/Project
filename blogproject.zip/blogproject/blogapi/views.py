from rest_framework import generics, permissions
from .models import Post, Comment
from .serializers import PostSerializer, CommentSerializer
from rest_framework.authtoken.models import Token
from rest_framework.permissions import IsAuthenticatedOrReadOnly

class PostListCreate(generics.ListCreateAPIView):
    queryset = Post.objects.order_by('-updated_at')
    serializer_class = PostSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)

class PostRetrieveUpdateDestroy(generics.RetrieveUpdateDestroyAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]


class CommentListCreate(generics.ListCreateAPIView):  # Handles both GET and POST
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        # Filter comments by post ID from URL
        return Comment.objects.filter(post_id=self.kwargs['pk']).order_by('-created_at')

    def perform_create(self, serializer):
        # Automatically set the post and author when creating a comment
        post = generics.get_object_or_404(Post, pk=self.kwargs['pk'])
        serializer.save(author=self.request.user, post=post)


def get_user_token(user):
    try:
        return Token.objects.get(user=user).key
    except Token.DoesNotExist:
        token = Token.objects.create(user=user)
        return token.key        